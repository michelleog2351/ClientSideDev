// Create an empty array to store data received from the database 
var allResults = [];
var round = 1; // Set round to 1

$(document).ready(function()
{
    nav();  // Call the nav function to initialize navigation
	getRoundDD(); // Call the function for dropdown selection
    getResultsTB(round); // Call to fetch & display results in table based on the selected round in the dropdown menu
});

function getRoundDD()
{	
	// This endpoint retrieves unique rounds 
	$.getJSON(`http://localhost/a2/ajax/getRounds.php`, function(data) 
	{	
		// Populate dropdown with teams data
		$.each(data.results, function(index, value)
		{
			$("#rounds").append(`<option value='${value.round}'>${value.round}</option>`);
		});
	});

	// Event handler for dropdown change
	$("#rounds").change(function() 
	{
	    var round = $(this).val();
		getResultsTB(round);

		$("#tbody").empty();

		var thisTable = "";

		$.getJSON(`http://localhost/a2/ajax/getResultsByRound.php?round=${round}`, function(data) {

			$.each(data.results, function(index, value)
			{
					thisTable += `<tr>`;
					thisTable += `<td>${value.date}</td>`;
					thisTable += `<td>${value.round}</td>`;

					// Team 1
					thisTable += `<td><img src="logos/${value.team1}.png">${value.team1}</td>`;
					thisTable += `<td><input class="form-control input-sm" id='team1Goals${value.id}' type='text' value="${value.team1Goals}"name='team1Goals' size='1'></td>`;
					thisTable += `<td><b>-</b></td>`;
					thisTable += `<td><input class="form-control input-sm"id='team1Points${value.id}' type='text' value="${value.team1Points}"name='team1Points' size='1'></td>`;

					thisTable += `<td></td>`;

					// Team 2
					thisTable += `<td><input class="form-control input-sm" id='team2Goals${value.id}' type='text' value="${value.team2Goals}"name='team2Goals' size='1'></td>`;
					thisTable += `<td><b>-</b></td>`;
					thisTable += `<td><input class="form-control input-sm" id='team2Points${value.id}' type='text' value="${value.team2Points}"name='team2Points' size='1'></td>`;
					thisTable += `<td></td>`;
					thisTable += `<td><img src="logos/${value.team2}.png">${value.team2}</td>`;
					
					thisTable += `<td>D${value.division} Rd${value.round}</td>`;

					// Update & Delete Buttons
					thisTable += `<td><button value="${value.id}" class="updateBtn btn btn-primary" id="updateButton">UPDATE</button></td>`;
					thisTable += `<td><button value="${value.id}" class="deleteBtn btn btn-primary" id="deleteButton">DELETE</button></td>`;
					thisTable += `</tr>`;
			})
				$("#tbody").html(thisTable);
		});
	});
}

	function getResultsTB(round)
	{
		$.getJSON(`http://localhost/a2/ajax/getResultsByRound.php?round=${round}`, function(data)   
		{
			//allResults = data;
			var thisTable = "";
			// Populate the table based on the selected team

			$.each(data.results, function(index, value)
			{	
				//console.log(value);
				// Construct table rows for the selected team's players
				thisTable += `<tr>`;
				thisTable += `<td>${value.date}</td>`;
				thisTable += `<td>${value.round}</td>`;

				// Team 1
				thisTable += `<td><img src="logos/${value.team1}.png">${value.team1}</td>`;
				thisTable += `<td><input class="form-control input-sm" id='team1Goals${value.id}' type='text' value="${value.team1Goals}"name='team1Goals' size='1'></td>`;
				thisTable += `<td><b>-</b></td>`;
				thisTable += `<td><input class="form-control input-sm"id='team1Points${value.id}' type='text' value="${value.team1Points}"name='team1Points' size='1'></td>`;

				thisTable += `<td></td>`;

				// Team 2
				thisTable += `<td><input class="form-control input-sm" id='team2Goals${value.id}' type='text' value="${value.team2Goals}"name='team2Goals' size='1'></td>`;
				thisTable += `<td><b>-</b></td>`;
				thisTable += `<td><input class="form-control input-sm" id='team2Points${value.id}' type='text' value="${value.team2Points}"name='team2Points' size='1'></td>`;
				thisTable += `<td></td>`;
				thisTable += `<td><img src="logos/${value.team2}.png">${value.team2}</td>`;
						
				thisTable += `<td>D${value.division} Rd${value.round}</td>`;

				// Update & Delete Buttons
				thisTable += `<td><button value="${value.id}" class="updateBtn btn btn-primary" id="updateButton">UPDATE</button></td>`;
				thisTable += `<td><button value="${value.id}" class="deleteBtn btn btn-primary" id="deleteButton">DELETE</button></td>`;
				thisTable += `</tr>`;
			})
			$("#tbody").html(thisTable);

			/////////////// Event Handler for Update Button //////////////		
			$(".updateBtn").click(function() 
			{
				//alert($(this).val());
				let id = $(this).val();

				let team1Goals = $(`#team1Goals${id}`).val();
				let team1Points = $(`#team1Points${id}`).val();
				alert(`${team1Goals}-${team1Points}`);

				let team2Goals = $(`#team2Goals${id}`).val();
				let team2Points = $(`#team2Points${id}`).val();
				alert(`${team2Goals}-${team2Points}`);

				$.post(`http://localhost/a2/ajax/updateResults.php`, 
				{ 
					"id": id, 
					"team1Goals": team1Goals, 
					"team1Points": team1Points,
					"team2Goals": team2Goals, 
					"team2Points": team2Points
				});
				alert("Update complete");
			});

			//////////////// Event Handler for Delete Button ///////////////
			$(".deleteBtn").click(function() 
			{
				//alert($(this).val());

				let id = $(this).val();

				alert(id);
				alert("Are you sure you want to delete?");
				
				$.post("http://localhost/a2/ajax/deleteResults.php", 
				{
					"id": id
				});
				alert("Row deleted");
			});
		})
	} 