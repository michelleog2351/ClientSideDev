// Create an empty array to store data received from the database 
var data = [];

// Wait for the document to be fully loaded before executing any code
$(document).ready(function() 
{
    nav(); // Call the nav function to initialize navigation
    
    ///////// getTeams Button /////////////
   $("#getTeams").click(function()
    {
        $.ajax({
			url: "http://localhost/a2/ajax/getTeams.php", // URL to fetch data from
			cache: false, // NB!! Disable caching
			type: "GET", // HTTP GET method
			dataType: "json", // Expected data type
			success: successFunc, // Callback function to handle successful response
			error: errorFunc // Callback function to handle error
		});

        function successFunc(data)          
		{
            var tAValue = "";

			$.each(data.teams, function(index, value)
			{
				tAValue = JSON.stringify({ "teams": data.teams }, null, 2);
            })
                $("textArea").val(tAValue);
                //console.log(tAValue);
		}

        // Callback function for AJAX error
		function errorFunc(xhr,status,strError) 
		{
			$("#myDiv").text("There was an error!");
			console.log("Error: "+ strError);
		}
    });

	///////// getPlayers Button /////////////
   $("#getPlayers").click(function()
    {
        $.ajax({
			url: "http://localhost/a2/ajax/getPlayers.php", // URL to fetch data from
			cache: false, // NB!! Disable caching
			type: "GET", // HTTP GET method
			dataType: "json", // Expected data type
			success: successFunc, // Callback function to handle successful response
			error: errorFunc // Callback function to handle error
		});

        function successFunc(data)          
		{
            var tAValue = "";

			$.each(data.players, function(index, value)
			{
				tAValue = JSON.stringify({ "players": data.players }, null, 2);
            })

            $("textArea").val(tAValue);
            //console.log(tAValue);		
		}

        // Callback function for AJAX error
		function errorFunc(xhr,status,strError) 
		{
			$("#myDiv").text("There was an error!");
			console.log("Error: "+ strError);
		}
    });

	///////// getResults Button /////////////
    $("#getResults").click(function()
    {
        $.ajax({
			url: "http://localhost/a2/ajax/getResults.php", // URL to fetch data from
			cache: false, // NB!! Disable caching
			type: "GET", // HTTP GET method
			dataType: "json", // Expected data type
			success: successFunc, // Callback function to handle successful response
			error: errorFunc // Callback function to handle error
		});

        function successFunc(data)          
		{
            var tAValue = "";

			$.each(data.results, function(index, value)
			{
				tAValue = JSON.stringify({ "results": data.results }, null, 2);
            });
			
            $("textArea").val(tAValue);
            //console.log(tAValue);
		}

        // Callback function for AJAX error
		function errorFunc(xhr,status,strError) 
		{
			$("#myDiv").text("There was an error!");
			console.log("Error: "+ strError);
		}
    });
    
	///////// getResults By Round Button /////////////
    $("#getResultsByRound").click(function()
    {
        var currentRound = 1;

        $.ajax({
			url: `http://localhost/a2/ajax/getResultsByRound.php?round=${currentRound}`, 
			cache: false, // NB!! Disable caching
			type: "GET", // HTTP GET method
			dataType: "json", // Expected data type
			success: successFunc, // Callback function to handle successful response
			error: errorFunc // Callback function to handle error
		});

        function successFunc(data)          
		{
            var tAValue = "";

			$.each(data.results, function(index, value)
			{
				tAValue = JSON.stringify({ "results": data.results }, null, 2);
            });
			
            $("textArea").val(tAValue);
            //console.log(tAValue);
		}

        // Callback function for AJAX error
		function errorFunc(xhr,status,strError) 
		{
			$("#myDiv").text("There was an error!");
			console.log("Error: "+ strError);
		}
    });
});

