/* Navigation function to dynamically generate navigation menu items */
function nav()
{
    $("nav").html(
        `<ul class="navbar-nav">

            <li class="nav-item">
                <a class="nav-link text-dark" href="index.html">JSON Data</a>
            </li> 

            <li class="nav-item">
                <a class="nav-link text-dark" href="teams.html">Teams</a>
            </li> 
            
            <li class="nav-item">
                <a class="nav-link text-dark" href="players.html">Players</a>
            </li> 

            <li class="nav-item">
                <a class="nav-link text-dark" href="results.html">Results</a>
            </li> 

            <li class="nav-item">
                <a class="nav-link text-dark" href="tables.html">Tables</a>
            </li> 
        </ul>`
    );

    // If user is logged in...
    if(sessionStorage.getItem("login") == "true")
    {
        $("nav").append(
            `<ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link text-dark" href="admin.html">Admin</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link text-dark" href="login.html" id="logout">Logout</a>
                </li>
            </ul>`
        );
    }

    // Else append login option
    else
    {
        $("nav").append(
            `<ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link text-dark" href="login.html">Login</a>
                </li>
            </ul> `   
        );
    }
}
