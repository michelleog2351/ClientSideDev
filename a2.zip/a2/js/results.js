// Create an empty array to store data received from the database 
var data = [];

var currentRound = 1; // Keeps track of the current round
var nextRound = 2; // Keeps track of the next round
var prevRound = 7; // Keeps track of the previous round
var numOfRounds = 7; // Total number of rounds

$(document).ready(function()
{
   nav(); // Call the nav function to initialize navigation
   getResults(currentRound); // Call the getResults function to fetch initial results

	///////// Event Handler for Next Button /////////////
	$("#next").click(function(event)
	{ 
		event.preventDefault(); // Prevents default action of the button

		/* To calculate the next round number...
		 * Modulo the nextRound by numOfRounds returns the remainder.
		 * This ensures that nextRound stays within the range of 1-7
		 *
	     * Plus 1 to increment the result
		 * Therefore if nextRound is at the max round, it will loop back to 1.
		 * i.e. 7 --> 1 
		 */

		nextRound = (nextRound % numOfRounds) + 1;
		currentRound = (currentRound % numOfRounds) + 1; // similar process with currentRound
		prevRound = (prevRound % numOfRounds) + 1; // similar process with prevRound

		getResults(nextRound); // Call getResults to fetch and display results for the next round
		roundUpdate(); // Call roundUpdate to update the round labels
		//console.log(currentRound);
	});

	///////// Event Handler for Previous Button ///////////
	$("#previous").click(function(event)
	{
		event.preventDefault();

		/* To calculate the previous round number...
		 */

		// Decrement current round by 1
		currentRound = currentRound - 1;

		// if the current round is less than 1, 
		if (currentRound < 1) 
		{
			// set back/loop back to 7 (so won't be out of range)
			currentRound = numOfRounds;
		}
	
		// Also we need to update the next round again
		nextRound = currentRound % numOfRounds + 1;
	
		// Calc previous round by taking away from current round
		prevRound = currentRound - 1;

		// if the prev round is less than 1, also loop back to 7 
		if (prevRound < 1) 
		{
			prevRound = numOfRounds;
		}

        getResults(prevRound); // Call getResults to fetch and display results for the previous round
        roundUpdate(); // Call roundUpdate to update the round labels

		$("#teams").trigger("keyup"); // triggers keyup()
		//console.log(currentRound);
	});

	$("#teams").keyup(search);  // assign with the search function

	// search function
	function search()
	{
		$.getJSON(`http://localhost/a2/ajax/getResultsByRound.php?round=${currentRound}`, function(data)  
		{
			$("#teams").keyup(function()
			{
				//console.log($(this).val());
				var newSearch = $(this).val().toUpperCase();

				currentRound = $("#roundLabel").text().split(" ")[1]; // Extract the current round No from the text content of label

				// Filter results data based on team names
				var newFilter = data.results.filter(function(data)
				{
					var teamName1 = data.team1.toUpperCase();
					var teamName2 = data.team2.toUpperCase();

					// Check if either team name includes the entered search query
					return teamName1.includes(newSearch) || teamName2.includes(newSearch);
				}); 

				var thisTable = "";

				// Iterate over the filtered result
				$.each(newFilter, function(index, value)
				{
					thisTable += `<tr>`;
					thisTable += `<td>${value.date}</td>`;
					thisTable += `<td>${currentRound}</td>`;
					thisTable += `<td><img src="logos/${value.team1}.png">${value.team1}</td>`;
					thisTable += `<td>${value.team1Goals}-${value.team1Points}</td>`; // team1 points and goals
					thisTable += `<td>${value.team2Goals}-${value.team2Points}</td>`; // team2 points and goals
					thisTable += `<td><img src="logos/${value.team2}.png">${value.team2}</td>`;
					thisTable += `<td>D${value.division} Rd${currentRound}</td>`;
					thisTable += `</tr>`;				
				})
					$("#tbody").html(thisTable);
			});
		});
	}
});

	// Function to update the Round numbers on the label & buttons
	function roundUpdate()
	{
		$("#next").html("Round " + nextRound + " >>");
		$("#roundLabel").html("Round " + currentRound);
		$("#previous").html("<< Round " + prevRound);
	}

	// function to fetch & display results in table based on the current round
	function getResults()
	{
		$.getJSON(`http://localhost/a2/ajax/getResultsByRound.php?round=${currentRound}`, function(data)  
		{
			var thisTable = "";
			// Populate the table based on the selected team
			$.each(data.results, function(index, value)
			{
				thisTable += `<tr>`;
				thisTable += `<td>${value.date}</td>`;
				thisTable += `<td>${currentRound}</td>`;
                thisTable += `<td><img src="logos/${value.team1}.png">${value.team1}</td>`;
                thisTable += `<td>${value.team1Goals}-${value.team1Points}</td>`; // team points and goals
                thisTable += `<td>${value.team2Goals}-${value.team2Points}</td>`; // team points and goals
                thisTable += `<td><img src="logos/${value.team2}.png">${value.team2}</td>`;
                thisTable += `<td>D${value.division} Rd${currentRound}</td>`;
				thisTable += `</tr>`;	
				// console.log(value);
			})
			$("#tbody").html(thisTable);        	
		});
	}