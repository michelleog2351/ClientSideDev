// Create an empty array to store data received from the database 
var data = [];

var win=0;
var lose=0;
var draw=0;
var played=0;
var diff=0;
var pts=0;

$(document).ready(function()
{
   // add your jQuery code here
   nav();
   getTableResults();
   //GameResults();
   //displayTable();

	function getTableResults()
	{
		var division = 1;
		$.getJSON(`http://localhost/a2/ajax/getResultsByDivision.php?division=${division}`, function(divData)  
		{
			data = divData;
			noGamesPlayed(displayTable);
			GameResults();
			displayTable();
			console.log(data);
		});

	}

	function noGamesPlayed(callfunction)
	{	
		
		$.each(data.results, function(index, value)
		{
			$.getJSON("http://localhost/a2/ajax/getNoGamesPlayed.php", function(noGamesData)  
			{
				value.gamesPlayed = 0; // Define
				value.gamesPlayed = noGamesData.results[0].gamesPlayed;
				console.log(noGamesData.results[0].gamesPlayed);
				callfunction();
			});
		});
	}

	// one goal = 3 points
	// I need to calculate their total points in one match and compare against the opposition
	// For wins: if team1 score > team2 score its a win
	// If its a loss: If team1 score is less than team2 score its a loss
	// Otherwise its a draw. draw++

	function GameResults()
	{
		// for(data.results.team)
		// {
	
	$.getJSON(`http://localhost/a2/ajax/getResultsByDivision.php`, function(data)  
		{
			$.each(data.results, function(index, value) 
			{
				// Reset 
				win = 0;
				lose = 0;
				draw = 0;
				played = value.gamesPlayed;
				diff = 0;
				pts = 0;

				$.each(value.results, function(index, result) 
				{
					var team = result.team1;

					// Determine whether the team is team1 or team2 in the result
					if (result.team1 == team) 
					{
						played++;
						diff += result.team1Goals - result.team2Goals;

						if (result.team1Points > result.team2Points) 
						{
							win++;
							pts += 3;
						} 
						
						else if (result.team1Points < result.team2Points) 
						{
							lose++;
						} 
						
						else 
						{
							draw++;
							pts++;
						}
					} 
					
					else if (result.team2 == team) 
					{
						played++;
						diff += result.team2Goals - result.team1Goals;

						if (result.team2Points > result.team1Points) 
						{
							win++;
							pts += 3;
						} 
						
						else if (result.team2Points < result.team1Points) 
						{
							lose++;
						} 
						
						else {
							draw++;
							pts++;
						}
					}
				});
				//  value.win = win;
				// value.lose = lose;
				// value.draw = draw;
				// value.played = played;
				// value.diff = diff;
				// value.pts = pts;
				// console.log(value.win);

			})
		});
	}

	function displayTable()
	{

			var thisTable = "";
			// Populate the table based on the selected team
			$.each(data.results, function(index, value)
			{
					// Construct table rows for the selected team's players
					thisTable += `<tr>`;
					thisTable += `<td>${index + 1}</td>`;
					thisTable += `<td>${value.team1}</td>`;
                    thisTable += `<td>${value.gamesPlayed}</td>`;
                    thisTable += `<td>${win}</td>`;
                    thisTable += `<td>${lose}</td>`;
                    thisTable += `<td>${draw}</td>`;
                    thisTable += `<td>${diff}</td>`;
                    thisTable += `<td>${pts}</td>`;
					thisTable += `</tr>`;
					// console.log(thisTable);
			})
			$("#tbody").html(thisTable);
	}
});