// Create an empty array to store data received from the database 
var data = [];

// Wait for the document to be fully loaded before executing any code
$(document).ready(function() 
{
   nav(); // Call the nav function to initialize navigation
   getTeams(); // Call the getTeams function to fetch teams data

	function getTeams()
	{
		$.getJSON(`http://localhost/a2/ajax/getTeams.php`, function(data)  
		{
			var thisTable = ""
			$.each(data.teams, function(index, value){
				thisTable += `<tr>`;
				thisTable += `<td><img src="logos/${value.name}.png">${value.name} (${value.name.substring(0, 3).toUpperCase()})</td>`;
				thisTable += `<td><a href="https://en.wikipedia.org/wiki/${value.name}_GAA">Info...</a></td>`;
				thisTable += `</tr>`;
				//console.log(value);
			})
			$("#tbody").html(thisTable);
		});
	}
});